import React, { useState, useCallback, useEffect } from 'react';
import { Header } from './components/Header';
import { Keyboard } from './components/Keyboard';
import { TypingArea } from './components/TypingArea';
import { Stats } from './components/Stats';
import { LessonSelector } from './components/LessonSelector';
import { GenerateTextModal } from './components/GenerateTextModal';
import { AchievementToast } from './components/AchievementToast';
import { useTyping } from './hooks/useTyping';
import { lessons } from './data/lessons';
import { badges } from './data/badges';
import type { TypingResult, Lesson, Badge as BadgeType } from './types';

const App: React.FC = () => {
  const [currentLesson, setCurrentLesson] = useState<Lesson>(() => {
    const savedLessonTitle = localStorage.getItem('currentLessonTitle');
    return lessons.find(l => l.title === savedLessonTitle) || lessons[0];
  });
  const [history, setHistory] = useState<TypingResult[]>(() => {
    const savedHistory = localStorage.getItem('typingHistory');
    return savedHistory ? JSON.parse(savedHistory) : [];
  });
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [wpmGoal, setWpmGoal] = useState<number>(() => {
    const savedGoal = localStorage.getItem('wpmGoal');
    return savedGoal ? parseInt(savedGoal, 10) : 40;
  });
  const [goalMetStatus, setGoalMetStatus] = useState<'met' | 'not-met' | null>(null);

  // Achievement State
  const [unlockedBadges, setUnlockedBadges] = useState<Set<string>>(() => {
    const savedBadges = localStorage.getItem('unlockedBadges');
    return savedBadges ? new Set(JSON.parse(savedBadges)) : new Set();
  });
  const [completedLessons, setCompletedLessons] = useState<Set<string>>(() => {
    const savedCompleted = localStorage.getItem('completedLessons');
    return savedCompleted ? new Set(JSON.parse(savedCompleted)) : new Set();
  });
  const [justUnlocked, setJustUnlocked] = useState<BadgeType | null>(null);

  const checkAndAwardBadges = useCallback((result: TypingResult) => {
    const newBadges: BadgeType[] = [];

    badges.forEach(badge => {
      if (unlockedBadges.has(badge.id)) return;

      let achieved = false;
      const newCompleted = new Set([...completedLessons, currentLesson.title]);
      
      if (badge.id === 'wpm-50' && result.wpm >= 50) achieved = true;
      if (badge.id === 'wpm-75' && result.wpm >= 75) achieved = true;
      if (badge.id === 'accuracy-100' && result.accuracy === 100) achieved = true;
      
      if (badge.id === 'beginner-complete') {
        const beginnerLessons = lessons.filter(l => l.level === 'Beginner');
        if (beginnerLessons.every(l => newCompleted.has(l.title))) achieved = true;
      }
      if (badge.id === 'intermediate-complete') {
        const intermediateLessons = lessons.filter(l => l.level === 'Intermediate');
        if (intermediateLessons.every(l => newCompleted.has(l.title))) achieved = true;
      }
      if (badge.id === 'advanced-complete') {
        const advancedLessons = lessons.filter(l => l.level === 'Advanced');
        if (advancedLessons.every(l => newCompleted.has(l.title))) achieved = true;
      }

      if (achieved) {
        newBadges.push(badge);
      }
    });

    if (newBadges.length > 0) {
      setUnlockedBadges(prev => new Set([...prev, ...newBadges.map(b => b.id)]));
      setJustUnlocked(newBadges[0]); // Show toast for the first new badge unlocked
    }
  }, [unlockedBadges, completedLessons, currentLesson.title]);

  const onComplete = useCallback((result: TypingResult) => {
    setHistory(prev => [...prev, result].slice(-10));
    setCompletedLessons(prev => new Set([...prev, currentLesson.title]));
    
    if (result.wpm >= wpmGoal) {
      setGoalMetStatus('met');
    } else {
      setGoalMetStatus('not-met');
    }
    checkAndAwardBadges(result);
  }, [wpmGoal, currentLesson.title, checkAndAwardBadges]);

  const {
    state,
    reset: resetTyping,
  } = useTyping(currentLesson.title, currentLesson.text, onComplete);

  const { status, userInput, currentIndex, wpm, accuracy, errorCount, totalPausedTime } = state;

  const handleReset = useCallback(() => {
    resetTyping();
    setGoalMetStatus(null);
  }, [resetTyping]);

  const handleSelectLesson = (lesson: Lesson) => {
    setCurrentLesson(lesson);
  };
  
  const handleCustomTextGenerated = (text: string) => {
    const customLesson: Lesson = {
        title: 'AI Generated Text',
        text: text,
        level: 'Custom'
    };
    setCurrentLesson(customLesson);
    setIsModalOpen(false);
  };

  // Persist state to localStorage
  useEffect(() => {
    localStorage.setItem('currentLessonTitle', currentLesson.title);
    localStorage.setItem('typingHistory', JSON.stringify(history));
    localStorage.setItem('wpmGoal', wpmGoal.toString());
    localStorage.setItem('unlockedBadges', JSON.stringify(Array.from(unlockedBadges)));
    localStorage.setItem('completedLessons', JSON.stringify(Array.from(completedLessons)));
  }, [currentLesson.title, history, wpmGoal, unlockedBadges, completedLessons]);

  const currentIndexInLessons = lessons.findIndex(l => l.title === currentLesson.title);
  const nextLesson = (
      currentLesson.level !== 'Custom' && 
      currentIndexInLessons > -1 && 
      currentIndexInLessons < lessons.length - 1
    ) ? lessons[currentIndexInLessons + 1] 
    : null;

  const handleNextLesson = () => {
    if (nextLesson) {
      handleSelectLesson(nextLesson);
    }
  };
  
  const formatTime = (ms: number) => {
    const totalSeconds = Math.floor(ms / 1000);
    const minutes = Math.floor(totalSeconds / 60).toString().padStart(2, '0');
    const seconds = (totalSeconds % 60).toString().padStart(2, '0');
    return `${minutes}:${seconds}`;
  };

  return (
    <div className="min-h-screen flex flex-col items-center p-4 sm:p-8 transition-colors duration-300 relative">
      <Header />
      <div className="w-full max-w-6xl mx-auto flex flex-col items-center gap-8 flex-grow">
        <Stats 
            wpm={wpm} 
            accuracy={accuracy} 
            history={history} 
            errorCount={errorCount}
            wpmGoal={wpmGoal}
            onWpmGoalChange={setWpmGoal}
            unlockedBadges={unlockedBadges}
        />

        <div className="w-full max-w-4xl relative">
            <TypingArea
                text={currentLesson.text}
                typedChars={userInput}
                currentIndex={currentIndex}
                status={status}
            />
            {status !== 'typing' && (
                <div className="absolute inset-0 flex flex-col items-center justify-center rounded-lg text-center">
                    {status === 'finished' ? (
                        <div className="px-4 py-6 sm:px-8 sm:py-6 bg-slate-900/60 rounded-md backdrop-blur-sm">
                            <h3 className="text-2xl font-bold text-white mb-2">
                                {goalMetStatus === 'met' ? 'Goal Achieved! 🎉' : 'Practice Complete!'}
                            </h3>
                            <p className="text-slate-300 mb-4">
                                {goalMetStatus === 'met' 
                                    ? `You surpassed your goal of ${wpmGoal} WPM.`
                                    : goalMetStatus === 'not-met'
                                    ? `Keep practicing to reach your goal of ${wpmGoal} WPM.`
                                    : 'Well done!'}
                            </p>
                            <div className="flex justify-center gap-4 text-lg font-semibold mb-6">
                                <span className="text-sky-400">WPM: {wpm.toFixed(0)}</span>
                                <span className="text-emerald-400">Accuracy: {accuracy.toFixed(1)}%</span>
                            </div>
                            <div className="flex justify-center gap-4">
                                <button
                                    onClick={handleReset}
                                    className="px-6 py-2 bg-slate-600 text-white font-semibold rounded-lg hover:bg-slate-500 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-slate-900 focus:ring-slate-500 transition-colors shadow-lg"
                                >
                                    Retry
                                </button>
                                {nextLesson && (
                                    <button
                                        onClick={handleNextLesson}
                                        className="px-6 py-2 bg-sky-600 text-white font-semibold rounded-lg hover:bg-sky-500 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-slate-900 focus:ring-sky-500 transition-colors shadow-lg"
                                    >
                                        Next Lesson
                                    </button>
                                )}
                            </div>
                        </div>
                    ) : status === 'idle' ? (
                        <p className="text-lg text-slate-200 font-medium mb-4 px-4 py-2 bg-slate-900/60 rounded-md backdrop-blur-sm">
                            Press any key to begin
                        </p>
                    ) : ( // paused
                      <p className="text-lg text-slate-200 font-medium mb-4 px-4 py-2 bg-slate-900/60 rounded-md backdrop-blur-sm">
                          Paused (Total: {formatTime(totalPausedTime)})
                      </p>
                    )}
                </div>
            )}
        </div>
        
        <Keyboard activeChar={currentLesson.text[currentIndex]} />

        <div className="w-full max-w-4xl mt-4 flex flex-col sm:flex-row gap-4 items-center">
          <LessonSelector lessons={lessons} onSelect={handleSelectLesson} activeLessonTitle={currentLesson.title}/>
          <button 
            onClick={() => setIsModalOpen(true)}
            className="w-full sm:w-auto flex-shrink-0 px-4 py-2 bg-indigo-600 text-white font-semibold rounded-lg hover:bg-indigo-500 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-slate-900 focus:ring-indigo-500 transition-colors"
          >
            Generate Custom Text with AI
          </button>
        </div>
      </div>
      <GenerateTextModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        onGenerate={handleCustomTextGenerated}
      />
      <AchievementToast 
        badge={justUnlocked}
        onClose={() => setJustUnlocked(null)}
      />
    </div>
  );
};

export default App;