import React, { useEffect, useState } from 'react';
import type { Badge } from '../types';

interface AchievementToastProps {
  badge: Badge | null;
  onClose: () => void;
}

export const AchievementToast: React.FC<AchievementToastProps> = ({ badge, onClose }) => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    if (badge) {
      setVisible(true);
      const timer = setTimeout(() => {
        setVisible(false);
        // Wait for animation to finish before calling onClose
        setTimeout(onClose, 500);
      }, 4000); // Show for 4 seconds

      return () => clearTimeout(timer);
    }
  }, [badge, onClose]);

  if (!badge) return null;

  return (
    <div
      className={`fixed bottom-5 right-5 w-full max-w-xs p-4 bg-slate-800 border border-slate-700 rounded-lg shadow-2xl z-50 transform ${
        visible ? 'toast-enter' : 'toast-exit'
      }`}
    >
      <div className="flex items-center">
        <div className="flex-shrink-0 text-3xl">{badge.icon}</div>
        <div className="ml-3">
          <p className="font-bold text-sky-400">Badge Unlocked!</p>
          <p className="text-sm text-slate-300">{badge.name}</p>
        </div>
      </div>
    </div>
  );
};