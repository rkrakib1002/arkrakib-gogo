import React from 'react';
import type { Badge as BadgeType } from '../types';

interface BadgeProps {
  badge: BadgeType;
  isUnlocked: boolean;
}

export const Badge: React.FC<BadgeProps> = ({ badge, isUnlocked }) => {
  return (
    <div className="relative group">
      <div 
        className={`w-16 h-16 bg-slate-700/50 rounded-full flex items-center justify-center transition-all duration-300 transform group-hover:scale-110 ${
          isUnlocked ? '' : 'grayscale opacity-50'
        }`}
      >
        <span className="text-4xl">{badge.icon}</span>
      </div>
      <div className="absolute bottom-full mb-2 w-48 left-1/2 -translate-x-1/2 p-2 bg-slate-900 text-white text-xs rounded-md shadow-lg opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none z-10 text-center">
        <p className="font-bold text-sky-400">{badge.name}</p>
        <p className="text-slate-300">{badge.description}</p>
        <div className="absolute top-full left-1/2 -translate-x-1/2 w-0 h-0 border-x-4 border-x-transparent border-t-4 border-t-slate-900"></div>
      </div>
    </div>
  );
};