import React, { useState, useEffect } from 'react';
import { generatePracticeText } from '../services/geminiService';

interface GenerateTextModalProps {
  isOpen: boolean;
  onClose: () => void;
  onGenerate: (text: string) => void;
}

export const GenerateTextModal: React.FC<GenerateTextModalProps> = ({ isOpen, onClose, onGenerate }) => {
  const [topic, setTopic] = useState('');
  const [includeNumbers, setIncludeNumbers] = useState(false);
  const [includeSymbols, setIncludeSymbols] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [show, setShow] = useState(false);

  useEffect(() => {
    if (isOpen) {
      setShow(true);
    } else {
      setShow(false);
    }
  }, [isOpen]);

  const handleGenerate = async () => {
    if (!topic.trim()) {
      setError('Please enter a topic.');
      return;
    }
    setIsLoading(true);
    setError(null);
    try {
      const text = await generatePracticeText(topic, includeNumbers, includeSymbols);
      onGenerate(text);
      setTopic('');
      setIncludeNumbers(false);
      setIncludeSymbols(false);
    } catch (err) {
      setError('An error occurred while generating text. The AI service may be unavailable. Please check the console for details and try again later.');
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };
  
  const handleTopicChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setTopic(e.target.value);
    if(error) setError(null);
  };
  
  const handleClose = () => {
    setShow(false);
    setTimeout(onClose, 300); // Wait for animation to finish
  };

  if (!isOpen) return null;

  return (
    <div 
        className={`fixed inset-0 flex items-center justify-center z-50 p-4 transition-opacity duration-300 ${show ? 'opacity-100' : 'opacity-0'}`}
        onClick={handleClose}
        aria-modal="true"
        role="dialog"
    >
      <div className={`fixed inset-0 bg-black/60 backdrop-blur-sm transition-opacity duration-300 ${show ? 'opacity-100' : 'opacity-0'}`} />
      <div 
        className={`bg-slate-800 rounded-xl shadow-2xl p-6 w-full max-w-md border border-slate-700 transform transition-all duration-300 ${show ? 'scale-100 opacity-100' : 'scale-95 opacity-0'}`}
        onClick={(e) => e.stopPropagation()} // Prevent closing when clicking inside modal
      >
        <div className="flex justify-between items-center mb-4">
          <div className="flex items-center gap-2">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-indigo-400" viewBox="0 0 20 20" fill="currentColor">
                <path d="M5 3a2 2 0 00-2 2v2a2 2 0 002 2h2a2 2 0 002-2V5a2 2 0 00-2-2H5zM5 11a2 2 0 00-2 2v2a2 2 0 002 2h2a2 2 0 002-2v-2a2 2 0 00-2-2H5zM11 5a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2V5zM14 11a1 1 0 011 1v1h1a1 1 0 110 2h-1v1a1 1 0 11-2 0v-1h-1a1 1 0 110-2h1v-1a1 1 0 011-1z" />
            </svg>
            <h2 className="text-xl font-bold text-white">Generate Custom Text</h2>
          </div>
          <button onClick={handleClose} className="text-slate-400 hover:text-white transition-colors rounded-full p-1 focus:outline-none focus:ring-2 focus:ring-slate-500">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>
        <p className="text-slate-400 mb-6 text-sm">
          Enter any topic, and our AI will generate a unique paragraph for you to practice with.
        </p>
        <div>
          <label htmlFor="topic" className="block text-sm font-medium text-slate-300 mb-1">
            Topic
          </label>
          <input
            type="text"
            id="topic"
            value={topic}
            onChange={handleTopicChange}
            placeholder="e.g., Space Exploration, Famous Quotes"
            className="w-full bg-slate-700 border border-slate-600 rounded-md px-3 py-2 text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-sky-500 transition-colors"
            disabled={isLoading}
          />
        </div>
        <div className="mt-4 flex flex-col sm:flex-row sm:items-center gap-2 sm:gap-4">
            <h3 className="text-sm font-medium text-slate-300">Mix in:</h3>
            <div className="flex items-center gap-4">
                <label className="flex items-center text-sm text-slate-300 cursor-pointer group">
                    <input type="checkbox" checked={includeNumbers} onChange={(e) => setIncludeNumbers(e.target.checked)} className="sr-only" disabled={isLoading} />
                    <div className={`w-4 h-4 rounded border-2 flex items-center justify-center transition-colors ${includeNumbers ? 'bg-sky-500 border-sky-500' : 'bg-slate-700 border-slate-500 group-hover:border-sky-500'}`}>
                        {includeNumbers && <svg className="w-3 h-3 text-white" fill="none" viewBox="0 0 12 12"><path d="M1 5.5L4.5 9L11 2.5" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/></svg>}
                    </div>
                    <span className="ml-2">Numbers</span>
                </label>
                 <label className="flex items-center text-sm text-slate-300 cursor-pointer group">
                    <input type="checkbox" checked={includeSymbols} onChange={(e) => setIncludeSymbols(e.target.checked)} className="sr-only" disabled={isLoading} />
                    <div className={`w-4 h-4 rounded border-2 flex items-center justify-center transition-colors ${includeSymbols ? 'bg-sky-500 border-sky-500' : 'bg-slate-700 border-slate-500 group-hover:border-sky-500'}`}>
                        {includeSymbols && <svg className="w-3 h-3 text-white" fill="none" viewBox="0 0 12 12"><path d="M1 5.5L4.5 9L11 2.5" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/></svg>}
                    </div>
                    <span className="ml-2">Symbols</span>
                </label>
            </div>
        </div>
        {error && <p className="text-red-500 text-sm mt-2">{error}</p>}
        <div className="mt-6 flex justify-end gap-4">
          <button
            onClick={handleClose}
            className="px-4 py-2 bg-slate-600 text-white font-semibold rounded-lg hover:bg-slate-500 focus:outline-none transition-colors disabled:opacity-50"
            disabled={isLoading}
          >
            Cancel
          </button>
          <button
            onClick={handleGenerate}
            className="px-4 py-2 bg-indigo-600 text-white font-semibold rounded-lg hover:bg-indigo-500 focus:outline-none transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center w-28"
            disabled={isLoading || !topic.trim()}
          >
            {isLoading ? (
                <svg className="animate-spin h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
            ) : 'Generate'}
          </button>
        </div>
      </div>
    </div>
  );
};
