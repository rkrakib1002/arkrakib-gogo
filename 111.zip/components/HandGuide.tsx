import React from 'react';
import { FINGER_COLORS } from '../constants';

interface HandGuideProps {
  activeFinger: string;
}

const Finger = ({ fingerId, activeFinger, className }: { fingerId: string, activeFinger: string, className: string }) => {
    const isActive = activeFinger === fingerId;
    const colorClasses = FINGER_COLORS[fingerId as keyof typeof FINGER_COLORS] || '';
    
    const baseClasses = `absolute border-2 rounded-full transition-all duration-200 ease-in-out`;
    const inactiveClasses = 'bg-slate-900/40 border-slate-500';
    const activeClasses = isActive
        ? `${colorClasses.replace('/80', '/60')} scale-110 shadow-lg`
        : inactiveClasses;

    return <div className={`${baseClasses} ${activeClasses} ${className}`} />;
};

export const HandGuide: React.FC<HandGuideProps> = ({ activeFinger }) => {
    return (
        <div className="absolute inset-x-0 -bottom-12 sm:-bottom-8 h-56 flex justify-center pointer-events-none z-20">
            <div className="relative w-full max-w-2xl h-full">
                {/* Palms */}
                <div className="absolute left-[22%] top-[45%] w-32 h-20 border-2 border-slate-500 rounded-br-full rounded-tl-full transform -rotate-[15deg] border-t-transparent border-l-transparent" />
                <div className="absolute right-[22%] top-[45%] w-32 h-20 border-2 border-slate-500 rounded-bl-full rounded-tr-full transform rotate-[15deg] border-t-transparent border-r-transparent" />
                
                {/* Left Hand Fingers */}
                <Finger fingerId="left-pinky" activeFinger={activeFinger} className="left-[14%] top-[8%] w-8 sm:w-9 h-24 transform -rotate-[25deg]" />
                <Finger fingerId="left-ring" activeFinger={activeFinger} className="left-[22%] sm:left-[23%] top-0 w-8 sm:w-9 h-28 transform -rotate-[10deg]" />
                <Finger fingerId="left-middle" activeFinger={activeFinger} className="left-[31%] sm:left-[32%] -top-[2%] w-8 sm:w-9 h-32" />
                <Finger fingerId="left-index" activeFinger={activeFinger} className="left-[40%] sm:left-[41%] top-0 w-10 sm:w-11 h-28 transform rotate-[10deg]" />
                {/* FIX: Corrected prop value to pass a string instead of a boolean */}
                <Finger fingerId="thumb" activeFinger={activeFinger.includes('thumb') ? 'thumb' : ''} className="left-[46%] sm:left-[48%] top-[60%] w-12 sm:w-14 h-14 sm:h-16 transform rotate-[45deg]" />
               
                {/* Right Hand Fingers */}
                <Finger fingerId="right-index" activeFinger={activeFinger} className="right-[40%] sm:right-[41%] top-0 w-10 sm:w-11 h-28 transform -rotate-[10deg]" />
                <Finger fingerId="right-middle" activeFinger={activeFinger} className="right-[31%] sm:right-[32%] -top-[2%] w-8 sm:w-9 h-32" />
                <Finger fingerId="right-ring" activeFinger={activeFinger} className="right-[22%] sm:right-[23%] top-0 w-8 sm:w-9 h-28 transform rotate-[10deg]" />
                <Finger fingerId="right-pinky" activeFinger={activeFinger} className="right-[14%] top-[8%] w-8 sm:w-9 h-24 transform rotate-[25deg]" />
                {/* FIX: Corrected prop value to pass a string instead of a boolean */}
                <Finger fingerId="thumb" activeFinger={activeFinger.includes('thumb') ? 'thumb' : ''} className="right-[46%] sm:right-[48%] top-[60%] w-12 sm:w-14 h-14 sm:h-16 transform -rotate-[45deg]" />
            </div>
        </div>
    );
};