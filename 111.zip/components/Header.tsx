import React from 'react';

export const Header: React.FC = () => {
  return (
    <header className="w-full max-w-6xl mx-auto text-center mb-8">
      <h1 className="text-4xl sm:text-5xl font-extrabold text-white">
        Typing <span className="text-sky-400">Master</span> Pro
      </h1>
      <p className="mt-2 text-lg text-slate-400">
        Hone your keyboard skills from the home row to lightning-fast sentences.
      </p>
    </header>
  );
};