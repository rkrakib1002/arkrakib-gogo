import React from 'react';
import { KEY_LAYOUT, FINGER_MAP, FINGER_COLORS } from '../constants';
import { HandGuide } from './HandGuide';

interface KeyboardProps {
  activeChar: string;
}

export const Keyboard: React.FC<KeyboardProps> = ({ activeChar }) => {
  const activeKey = activeChar ? activeChar.toLowerCase() : '';
  const activeFinger = FINGER_MAP[activeKey] || '';
  const activeColor = activeFinger ? FINGER_COLORS[activeFinger as keyof typeof FINGER_COLORS] : 'bg-sky-500/80 border-sky-400';

  return (
    <div className="w-full max-w-4xl relative mt-16 sm:mt-12">
      <HandGuide activeFinger={activeFinger} />
      <div className="w-full p-2 sm:p-4 bg-slate-950/50 rounded-xl shadow-2xl">
        <div className="flex flex-col gap-1 sm:gap-2">
          {KEY_LAYOUT.map((row, rowIndex) => (
            <div key={rowIndex} className="flex justify-center gap-1 sm:gap-2">
              {row.map((key) => {
                const finger = FINGER_MAP[key.toLowerCase()];
                const isHomeRow = ['a', 's', 'd', 'f', 'j', 'k', 'l', ';'].includes(key.toLowerCase());
                
                const baseClasses = 'h-10 sm:h-14 font-sans font-semibold text-sm sm:text-base text-slate-200 rounded-md sm:rounded-lg flex items-center justify-center transition-all duration-150 ease-in-out relative';
                const sizeClasses = 
                  key.length > 1 ? 'px-2 sm:px-4 flex-grow' : 'w-10 sm:w-14';

                const colorClasses = finger ? FINGER_COLORS[finger as keyof typeof FINGER_COLORS].replace('/80', '/20').replace(/border-\w+-\d+/, 'border-transparent border ') : 'bg-slate-700/50 border border-transparent';
                
                const activeClasses = key.toLowerCase() === activeKey 
                  ? `${activeColor} text-white scale-110 shadow-lg z-30` 
                  : 'hover:bg-slate-600/50';

                const homeRowMarker = isHomeRow ? <div className="absolute bottom-1.5 h-1 w-4 bg-slate-500 rounded-full"></div> : null;

                return (
                  <div key={key} className={`${baseClasses} ${sizeClasses} ${colorClasses} ${activeClasses}`}>
                    {key.length > 1 ? key : key.toUpperCase()}
                    {homeRowMarker}
                  </div>
                );
              })}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};