import React, { useState, useRef, useEffect } from 'react';
import type { Lesson } from '../types';

interface LessonSelectorProps {
  lessons: Lesson[];
  onSelect: (lesson: Lesson) => void;
  activeLessonTitle: string;
}

export const LessonSelector: React.FC<LessonSelectorProps> = ({ lessons, onSelect, activeLessonTitle }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [filter, setFilter] = useState<'All' | 'Beginner' | 'Intermediate' | 'Advanced'>('All');
  const [indicatorStyle, setIndicatorStyle] = useState({});
  const filterContainerRef = useRef<HTMLDivElement>(null);
  const dropdownRef = useRef<HTMLDivElement>(null);

  const handleSelect = (lesson: Lesson) => {
    onSelect(lesson);
    setIsOpen(false);
  };
  
  useEffect(() => {
    if (isOpen && filterContainerRef.current) {
      const container = filterContainerRef.current;
      const activeButton = container.querySelector(`[data-filter="${filter}"]`) as HTMLElement;
      
      if (activeButton) {
        setIndicatorStyle({
          left: `${activeButton.offsetLeft}px`,
          width: `${activeButton.offsetWidth}px`,
        });

        const scrollLeft = activeButton.offsetLeft
          - (container.clientWidth / 2) 
          + (activeButton.clientWidth / 2);
        
        container.scrollTo({
          left: scrollLeft,
          behavior: 'smooth',
        });
      }
    }
  }, [filter, isOpen]);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const levels: ('Beginner' | 'Intermediate' | 'Advanced')[] = ['Beginner', 'Intermediate', 'Advanced'];
  const filterLevels: ('All' | 'Beginner' | 'Intermediate' | 'Advanced')[] = ['All', 'Beginner', 'Intermediate', 'Advanced'];

  const LessonButton = ({ lesson }: { lesson: Lesson }) => (
    <button
      onClick={() => handleSelect(lesson)}
      className={`w-full text-left px-3 py-2 text-sm rounded-md transition-colors flex items-center justify-between ${
        lesson.title === activeLessonTitle
          ? 'bg-sky-500 text-white font-semibold'
          : 'text-slate-200 hover:bg-slate-600'
      }`}
    >
      <span>{lesson.title}</span>
      {lesson.title === activeLessonTitle && (
        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M5 13l4 4L19 7"></path>
        </svg>
      )}
    </button>
  );

  return (
    <div className="relative w-full sm:w-auto flex-grow" ref={dropdownRef}>
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="w-full sm:w-64 flex justify-between items-center px-4 py-2 bg-slate-700 text-white font-semibold rounded-lg hover:bg-slate-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-slate-900 focus:ring-sky-500 transition-colors"
      >
        <span>{activeLessonTitle}</span>
        <svg
          className={`w-5 h-5 transition-transform duration-200 ${isOpen ? 'transform rotate-180' : ''}`}
          fill="none"
          stroke="currentColor"
          viewBox="0 0 24 24"
          xmlns="http://www.w3.org/2000/svg"
        >
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7"></path>
        </svg>
      </button>
      {isOpen && (
        <div className="absolute bottom-full mb-2 w-full sm:w-64 bg-slate-800 border border-slate-700 rounded-lg shadow-xl z-40 flex flex-col p-2">
          <div ref={filterContainerRef} className="relative flex items-center shrink-0 p-1 bg-slate-900/70 rounded-lg overflow-x-auto scrollbar-hide">
            <div 
                className="absolute top-1 bottom-1 bg-sky-600 rounded-md shadow-md transition-all duration-300 ease-in-out"
                style={indicatorStyle}
            />
            {filterLevels.map(level => (
              <button
                key={level}
                data-filter={level}
                onClick={() => setFilter(level)}
                className={`relative z-10 flex-shrink-0 text-center px-4 py-1.5 text-sm font-semibold transition-colors outline-none focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-offset-slate-800 focus-visible:ring-sky-500 rounded-md whitespace-nowrap ${
                  filter === level
                    ? 'text-white'
                    : 'text-slate-300 hover:text-white'
                }`}
              >
                {level}
              </button>
            ))}
          </div>
          <div className="overflow-y-auto max-h-52 mt-2">
            {filter === 'All' ? (
              levels.map(level => (
                <div key={level} className="mt-1">
                  <h4 className="px-2 py-1 text-xs font-bold text-sky-400 uppercase tracking-wider">{level}</h4>
                  {lessons
                    .filter(l => l.level === level)
                    .map((lesson) => (
                      <LessonButton key={lesson.title} lesson={lesson} />
                    ))}
                </div>
              ))
            ) : (
              lessons
                .filter(l => l.level === filter)
                .map((lesson) => (
                  <LessonButton key={lesson.title} lesson={lesson} />
                ))
            )}
          </div>
        </div>
      )}
    </div>
  );
};