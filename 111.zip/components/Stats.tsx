import React, { useState, useEffect } from 'react';
import type { TypingResult, Badge as BadgeType } from '../types';
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from 'recharts';
import { Badge } from './Badge';
import { badges } from '../data/badges';

interface StatsProps {
  wpm: number;
  accuracy: number;
  history: TypingResult[];
  errorCount: number;
  wpmGoal: number;
  onWpmGoalChange: (goal: number) => void;
  unlockedBadges: Set<string>;
}

const StatCard: React.FC<{ label: string; value: string | number; unit?: string }> = ({ label, value, unit }) => (
    <div className="bg-slate-800 p-4 rounded-lg shadow-md flex-1 text-center">
        <p className="text-sm text-slate-400 uppercase tracking-wider">{label}</p>
        <p className="text-4xl font-bold text-white">
            {value}
            {unit && <span className="text-2xl text-slate-400 ml-1">{unit}</span>}
        </p>
    </div>
);

const GoalCard: React.FC<{ goal: number; onGoalChange: (goal: number) => void }> = ({ goal, onGoalChange }) => {
    const [localGoal, setLocalGoal] = useState(goal.toString());

    useEffect(() => {
        setLocalGoal(goal.toString());
    }, [goal]);

    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        setLocalGoal(e.target.value);
    };

    const handleBlur = () => {
        const newGoal = parseInt(localGoal, 10);
        if (!isNaN(newGoal) && newGoal > 0) {
            onGoalChange(newGoal);
        } else {
            setLocalGoal(goal.toString()); // revert if invalid
        }
    };

    const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
        if (e.key === 'Enter') {
            (e.target as HTMLInputElement).blur();
        }
    };

    return (
        <div className="bg-slate-800 p-4 rounded-lg shadow-md flex-1 text-center flex flex-col justify-center">
            <p className="text-sm text-slate-400 uppercase tracking-wider">Goal</p>
            <div className="flex items-baseline justify-center">
                <input 
                    type="number"
                    value={localGoal}
                    onChange={handleChange}
                    onBlur={handleBlur}
                    onKeyDown={handleKeyDown}
                    className="text-4xl font-bold text-white bg-transparent w-24 text-center outline-none focus:bg-slate-700/50 rounded-md transition-colors"
                    aria-label="WPM Goal"
                    min="1"
                />
                <span className="text-2xl text-slate-400 ml-1">WPM</span>
            </div>
        </div>
    );
};

export const Stats: React.FC<StatsProps> = ({ wpm, accuracy, history, errorCount, wpmGoal, onWpmGoalChange, unlockedBadges }) => {
  const chartData = history.map((h, i) => ({ name: `Try ${i + 1}`, wpm: h.wpm, accuracy: h.accuracy }));
    
  return (
    <div className="w-full max-w-4xl flex flex-col gap-4">
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard label="WPM" value={wpm.toFixed(0)} />
        <StatCard label="Accuracy" value={accuracy.toFixed(1)} unit="%" />
        <StatCard label="Errors" value={errorCount} />
        <GoalCard goal={wpmGoal} onGoalChange={onWpmGoalChange} />
      </div>
      <div className="bg-slate-800 p-4 rounded-lg shadow-md h-48 md:h-64">
        <h3 className="text-sm text-slate-400 uppercase tracking-wider mb-2 text-center md:text-left">Progress</h3>
        {history.length > 1 ? (
          <ResponsiveContainer width="100%" height="85%">
            <LineChart data={chartData} margin={{ top: 5, right: 20, left: -10, bottom: 5 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#475569" />
              <XAxis dataKey="name" stroke="#94a3b8" fontSize={12} />
              <YAxis yAxisId="left" stroke="#38bdf8" fontSize={12} />
              <YAxis yAxisId="right" orientation="right" stroke="#4ade80" fontSize={12} domain={[0, 100]} />
              <Tooltip
                contentStyle={{
                  backgroundColor: 'rgba(30, 41, 59, 0.8)',
                  borderColor: '#475569',
                  borderRadius: '0.5rem'
                }}
                labelStyle={{ color: '#cbd5e1' }}
              />
              <Line yAxisId="left" type="monotone" dataKey="wpm" stroke="#38bdf8" strokeWidth={2} dot={{ r: 4 }} activeDot={{ r: 6 }} />
              <Line yAxisId="right" type="monotone" dataKey="accuracy" stroke="#4ade80" strokeWidth={2} />
            </LineChart>
          </ResponsiveContainer>
        ) : (
            <div className="flex items-center justify-center h-full text-slate-500 text-center p-4">
                <p>Complete a few rounds to see your progress chart.</p>
            </div>
        )}
      </div>
       <div className="bg-slate-800 p-4 rounded-lg shadow-md">
         <h3 className="text-sm text-slate-400 uppercase tracking-wider mb-4 text-center">Achievements</h3>
         <div className="flex flex-wrap justify-center gap-4">
            {badges.map(badge => (
              <Badge key={badge.id} badge={badge} isUnlocked={unlockedBadges.has(badge.id)} />
            ))}
         </div>
      </div>
    </div>
  );
};