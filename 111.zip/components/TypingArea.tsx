import React, { memo } from 'react';
import type { TypingStatus } from '../types';

interface TypingAreaProps {
  text: string;
  typedChars: (string | undefined)[];
  currentIndex: number;
  status: TypingStatus;
}

const Character: React.FC<{
  char: string;
  typedChar: string | undefined;
  isCurrent: boolean;
}> = ({ char, typedChar, isCurrent }) => {
  let className = "transition-colors duration-150 ease-in-out relative ";

  if (typedChar === undefined) {
    className += "text-slate-400";
  } else if (typedChar === char) {
    className += "text-emerald-400";
  } else {
    className += "text-red-400 bg-red-500/10 rounded underline decoration-red-500 decoration-1 underline-offset-4";
  }
  
  if (isCurrent) {
     className += " rounded";
  }

  return (
    <span className={className}>
      {isCurrent && (
        <span className="absolute left-0 top-0 bottom-0 w-0.5 bg-sky-400 animate-pulse" />
      )}
      {char}
    </span>
  );
};

const MemoizedCharacter = memo(Character);

export const TypingArea: React.FC<TypingAreaProps> = ({ text, typedChars, currentIndex, status }) => {
  const characters = text.split('');

  return (
    <div
      className={`bg-slate-800 p-6 rounded-lg shadow-lg relative font-mono text-2xl tracking-wider leading-relaxed select-none transition-opacity duration-300 ${
        status !== 'typing' ? 'opacity-40' : 'opacity-100'
      }`}
    >
      {characters.map((char, index) => (
        <MemoizedCharacter
          key={`${char}_${index}`}
          char={char}
          typedChar={typedChars[index]}
          isCurrent={index === currentIndex && status !== 'finished'}
        />
      ))}
    </div>
  );
};