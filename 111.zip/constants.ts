export const KEY_LAYOUT = [
  ['`', '1', '2', '3', '4', '5', '6', '7', '8', '9', '0', '-', '=', 'Backspace'],
  ['Tab', 'q', 'w', 'e', 'r', 't', 'y', 'u', 'i', 'o', 'p', '[', ']', '\\'],
  ['CapsLock', 'a', 's', 'd', 'f', 'g', 'h', 'j', 'k', 'l', ';', '\'', 'Enter'],
  ['Shift', 'z', 'x', 'c', 'v', 'b', 'n', 'm', ',', '.', '/', 'Shift'],
  [' ', ' ', ' ', ' ', 'Space', ' ', ' ', ' ', ' '],
];

export const FINGER_MAP: { [key: string]: string } = {
  // Left Hand
  '`': 'left-pinky', '1': 'left-pinky', 'q': 'left-pinky', 'a': 'left-pinky', 'z': 'left-pinky',
  '2': 'left-ring', 'w': 'left-ring', 's': 'left-ring', 'x': 'left-ring',
  '3': 'left-middle', 'e': 'left-middle', 'd': 'left-middle', 'c': 'left-middle',
  '4': 'left-index', 'r': 'left-index', 'f': 'left-index', 'v': 'left-index',
  '5': 'left-index', 't': 'left-index', 'g': 'left-index', 'b': 'left-index',
  // Right Hand
  '6': 'right-index', 'y': 'right-index', 'h': 'right-index', 'n': 'right-index',
  '7': 'right-index', 'u': 'right-index', 'j': 'right-index', 'm': 'right-index',
  '8': 'right-middle', 'i': 'right-middle', 'k': 'right-middle', ',': 'right-middle',
  '9': 'right-ring', 'o': 'right-ring', 'l': 'right-ring', '.': 'right-ring',
  '0': 'right-pinky', 'p': 'right-pinky', ';': 'right-pinky', '/': 'right-pinky',
  '-': 'right-pinky', '[': 'right-pinky', '\'': 'right-pinky',
  '=': 'right-pinky', ']': 'right-pinky', '\\': 'right-pinky',
  // Thumbs
  ' ': 'thumb',
};

export const FINGER_COLORS: { [key: string]: string } = {
  'left-pinky': 'bg-red-500/80 border-red-400',
  'left-ring': 'bg-orange-500/80 border-orange-400',
  'left-middle': 'bg-yellow-500/80 border-yellow-400',
  'left-index': 'bg-green-500/80 border-green-400',
  'thumb': 'bg-sky-500/80 border-sky-400',
  'right-index': 'bg-green-500/80 border-green-400',
  'right-middle': 'bg-yellow-500/80 border-yellow-400',
  'right-ring': 'bg-orange-500/80 border-orange-400',
  'right-pinky': 'bg-red-500/80 border-red-400',
};

export const FINGER_KEY_MAP: { [key: string]: string[] } = {
    'left-pinky': ['1', 'Q', 'A', 'Z'],
    'left-ring': ['2', 'W', 'S', 'X'],
    'left-middle': ['3', 'E', 'D', 'C'],
    'left-index': ['4', 'R', 'F', 'V', '5', 'T', 'G', 'B'],
    'left-thumb': ['SPACE'],
    'right-index': ['6', 'Y', 'H', 'N', '7', 'U', 'J', 'M'],
    'right-middle': ['8', 'I', 'K', ','],
    'right-ring': ['9', 'O', 'L', '.'],
    'right-pinky': ['0', 'P', ';', '/'],
    'right-thumb': ['SPACE'],
};

export const FINGER_TEXT_COLORS: { [key: string]: string } = {
  'left-pinky': 'text-red-500',
  'left-ring': 'text-orange-500',
  'left-middle': 'text-yellow-500',
  'left-index': 'text-green-500',
  'left-thumb': 'text-sky-500',
  'right-index': 'text-green-500',
  'right-middle': 'text-yellow-500',
  'right-ring': 'text-orange-500',
  'right-pinky': 'text-red-500',
  'right-thumb': 'text-sky-500',
};