import type { Badge } from '../types';

export const badges: Badge[] = [
  {
    id: 'wpm-50',
    name: 'Speedster',
    description: 'Reach 50 WPM on any lesson.',
    icon: '🚀',
  },
  {
    id: 'wpm-75',
    name: 'Velocity',
    description: 'Reach 75 WPM on any lesson.',
    icon: '⚡',
  },
  {
    id: 'accuracy-100',
    name: 'Perfectionist',
    description: 'Achieve 100% accuracy on any lesson.',
    icon: '🎯',
  },
  {
    id: 'beginner-complete',
    name: 'Home Row Hero',
    description: 'Complete all Beginner lessons.',
    icon: '🎓',
  },
  {
    id: 'intermediate-complete',
    name: 'Keyboard Journeyman',
    description: 'Complete all Intermediate lessons.',
    icon: '🌟',
  },
  {
    id: 'advanced-complete',
    name: 'Typing Titan',
    description: 'Complete all Advanced lessons.',
    icon: '👑',
  },
];