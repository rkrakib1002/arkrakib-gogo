import type { Lesson } from '../types';

export const lessons: Lesson[] = [
  // Beginner
  {
    title: 'Home Row Basics',
    text: 'asdf jkl; asdf jkl;',
    level: 'Beginner',
  },
  {
    title: 'Home Row Drills',
    text: 'ff jj dd kk ss ll aa ;; ff jj dd kk ss ll aa ;;',
    level: 'Beginner',
  },
  {
    title: 'Home Row Combinations',
    text: 'ad sk fj la; sal fad jak; all fall dads ask;',
    level: 'Beginner',
  },
  {
    title: 'Home Row Words',
    text: 'a sad dad adds a flask; a lad asks a sad lass;',
    level: 'Beginner',
  },
  {
    title: 'Top Row (E, R, I, U)',
    text: 'deer fire desk ride; like sure fake rule;',
    level: 'Beginner',
  },
  {
    title: 'Top Row Words',
    text: 'jerk sad life; ask a sad jade; a reader is ill;',
    level: 'Beginner',
  },
  {
    title: 'Bottom Row (C, V, N, M)',
    text: 'can man van cam; can a man see a cave; nice mice',
    level: 'Beginner',
  },
  // Intermediate
  {
    title: 'Common Words',
    text: 'The quick brown fox jumps over the lazy dog near the bank of the river.',
    level: 'Intermediate',
  },
  {
    title: 'Punctuation Practice',
    text: 'Hello, world! Isn\'t this great? I think so. She said, "Let\'s go!"',
    level: 'Intermediate',
  },
  {
    title: 'Longer Sentences',
    text: 'The ability to type quickly and accurately is a valuable skill in today\'s digital world, improving both productivity and communication.',
    level: 'Intermediate',
  },
  // Advanced
  {
    title: 'Code Snippet (JS)',
    text: 'function greet(name) { console.log(`Hello, ${name}!`); } const x = [1, 2, 3];',
    level: 'Advanced',
  },
  {
    title: 'Famous Quote',
    text: 'The only way to do great work is to love what you do. If you haven\'t found it yet, keep looking. Don\'t settle. - Steve Jobs',
    level: 'Advanced',
  },
  {
    title: 'Challenging Paragraph',
    text: 'The juxtaposition of the tranquil azure sky against the tumultuous, churning sea created a breathtakingly paradoxical vista for the awe-struck spectators.',
    level: 'Advanced',
  },
];