import { useState, useCallback, useEffect } from 'react';
import type { TypingStatus, TypingState, TypingResult } from '../types';

const isTypingKey = (key: string) => {
  return key.length === 1 || key === 'Backspace';
};

const getDefaultState = (text: string): TypingState => ({
  status: 'idle',
  userInput: Array(text.length).fill(undefined),
  currentIndex: 0,
  startTime: null,
  wpm: 0,
  accuracy: 100,
  errorCount: 0,
  pauseStartTime: null,
  totalPausedTime: 0,
  elapsedTime: 0,
});

export const useTyping = (lessonTitle: string, text: string, onComplete: (result: TypingResult) => void) => {
  const [state, setState] = useState<TypingState>(() => getDefaultState(text));

  // Load progress when lesson changes
  useEffect(() => {
    const storageKey = `typingProgress_${lessonTitle}`;
    const savedProgress = localStorage.getItem(storageKey);
    
    let loadedState: TypingState | null = null;
    if (savedProgress) {
      try {
        const parsed = JSON.parse(savedProgress) as Partial<TypingState>;
        if (parsed && parsed.userInput && parsed.userInput.length === text.length) {
            loadedState = { ...getDefaultState(text), ...parsed };
        }
      } catch (e) {
        console.error("Failed to parse saved typing progress, starting fresh.", e);
        localStorage.removeItem(storageKey); // Clear corrupted data
      }
    }

    if(loadedState) {
        const status = loadedState.status === 'typing' ? 'paused' : loadedState.status;
        setState({
          ...loadedState,
          status,
          pauseStartTime: status === 'paused' ? Date.now() : null,
        });
    } else {
        setState(getDefaultState(text));
    }
  }, [lessonTitle, text]);

  // Auto-save progress periodically
  useEffect(() => {
    if (state.status !== 'typing' && state.status !== 'paused') {
      return;
    }
    const storageKey = `typingProgress_${lessonTitle}`;
    const saveInterval = setInterval(() => {
      localStorage.setItem(storageKey, JSON.stringify(state));
    }, 3000); // Save every 3 seconds

    return () => clearInterval(saveInterval);
  }, [state, lessonTitle]);

  // Auto-save progress on page close/unload
  useEffect(() => {
    const storageKey = `typingProgress_${lessonTitle}`;
    const handleBeforeUnload = () => {
      if (state.status === 'typing' || state.status === 'paused') {
        localStorage.setItem(storageKey, JSON.stringify(state));
      }
    };
    window.addEventListener('beforeunload', handleBeforeUnload);
    return () => {
      window.removeEventListener('beforeunload', handleBeforeUnload);
    };
  }, [state, lessonTitle]);

  const reset = useCallback(() => {
    const storageKey = `typingProgress_${lessonTitle}`;
    localStorage.removeItem(storageKey);
    setState(getDefaultState(text));
  }, [lessonTitle, text]);

  const calculateStats = useCallback((typedCharsCount: number, errorCount: number, durationSeconds: number) => {
    const grossWPM = durationSeconds > 0 ? (typedCharsCount / 5) / (durationSeconds / 60) : 0;
    const accuracy = typedCharsCount > 0 ? ((typedCharsCount - errorCount) / typedCharsCount) * 100 : 100;
    return { wpm: Math.max(0, grossWPM), accuracy: Math.max(0, accuracy) };
  }, []);

  const handleKeyDown = useCallback((key: string) => {
    const storageKey = `typingProgress_${lessonTitle}`;

    if (state.status === 'idle' && isTypingKey(key)) {
      setState(prevState => ({
        ...prevState,
        status: 'typing',
        startTime: Date.now(),
      }));
      return;
    }

    setState(prevState => {
      if (prevState.status === 'finished' || prevState.status === 'idle') {
        return prevState;
      }
      
      if (prevState.status === 'paused') {
        const pauseDuration = Date.now() - (prevState.pauseStartTime as number);
        return {
          ...prevState,
          status: 'typing',
          totalPausedTime: prevState.totalPausedTime + pauseDuration,
          pauseStartTime: null,
        };
      }
      
      if (prevState.status === 'typing' && isTypingKey(key)) {
        let { userInput, currentIndex } = prevState;
        const updatedUserInput = [...userInput];

        if (key === 'Backspace') {
          if (currentIndex > 0) {
            currentIndex--;
            updatedUserInput[currentIndex] = undefined;
          }
        } else {
          if (currentIndex < text.length) {
            updatedUserInput[currentIndex] = key;
            currentIndex++;
          }
        }

        const errorCount = updatedUserInput.slice(0, currentIndex).reduce((acc, input, index) => {
          return (input !== undefined && input !== text[index]) ? acc + 1 : acc;
        }, 0);
        
        let nextStatus: TypingStatus = 'typing';
        if (currentIndex === text.length) {
          nextStatus = 'finished';
          localStorage.removeItem(storageKey);
          const elapsed = (Date.now() - (prevState.startTime as number));
          const durationSeconds = (elapsed - prevState.totalPausedTime) / 1000;
          const { wpm, accuracy } = calculateStats(currentIndex, errorCount, durationSeconds);
          onComplete({ wpm, accuracy, timestamp: Date.now() });
        }
        
        return {
          ...prevState,
          status: nextStatus,
          userInput: updatedUserInput,
          currentIndex,
          errorCount,
        };
      }
      return prevState;
    });
  }, [text, calculateStats, onComplete, lessonTitle, state.status]);

  // Timer effect for WPM, accuracy, and elapsed time
  useEffect(() => {
    let timer: ReturnType<typeof setInterval> | undefined;
    if (state.status === 'typing' && state.startTime) {
      timer = setInterval(() => {
        const elapsed = Date.now() - (state.startTime as number);
        const durationSeconds = (elapsed - state.totalPausedTime) / 1000;
        const { wpm, accuracy } = calculateStats(state.currentIndex, state.errorCount, durationSeconds);
        setState(s => s.status === 'typing' ? { ...s, wpm, accuracy, elapsedTime: elapsed - s.totalPausedTime } : s);
      }, 1000);
    }
    return () => clearInterval(timer);
  }, [state.status, state.startTime, state.totalPausedTime, state.currentIndex, state.errorCount, calculateStats]);

  // Inactivity timer
  useEffect(() => {
    let inactivityTimer: ReturnType<typeof setTimeout> | undefined;
    if (state.status === 'typing') {
      inactivityTimer = setTimeout(() => {
        setState(prevState => {
          if (prevState.status !== 'typing') return prevState;
          return {
            ...prevState,
            status: 'paused',
            pauseStartTime: Date.now(),
          };
        });
      }, 5000);
    }
    return () => clearTimeout(inactivityTimer);
  }, [state.currentIndex, state.status]);

  useEffect(() => {
    const keydownHandler = (e: KeyboardEvent) => {
      // Prevent browser shortcuts like search (/) or link find (')
      if (isTypingKey(e.key) && (e.key !== ' ' || (e.target as HTMLElement).tagName !== 'BODY')) {
        e.preventDefault();
      }
      if (e.key === 'Escape') {
        reset();
      } else {
        handleKeyDown(e.key);
      }
    };
    window.addEventListener('keydown', keydownHandler);
    return () => {
      window.removeEventListener('keydown', keydownHandler);
    };
  }, [handleKeyDown, reset]);

  return {
    state,
    reset,
  };
};