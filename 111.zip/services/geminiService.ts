import { GoogleGenAI } from "@google/genai";

// The GoogleGenAI instance is initialized using an API key from an environment variable.
// This is handled by the build environment. For the AI features to work,
// the process.env.API_KEY environment variable must be set.
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const generatePracticeText = async (topic: string, includeNumbers: boolean, includeSymbols: boolean): Promise<string> => {
  try {
    const promptBase = `Generate a single paragraph for a touch typing practice website on the topic of "${topic}". The paragraph must be between 40 and 70 words, flow well, and be interesting to type.`;

    let contentInstructions = 'The paragraph should contain words with proper capitalization, commas, and periods. Avoid complex symbols, numbers, or overly long words.';

    if (includeNumbers && includeSymbols) {
      contentInstructions = 'The paragraph must contain a mix of words, numbers (e.g., 123, 2024), and common keyboard symbols (e.g., !@#$%^&*).';
    } else if (includeNumbers) {
      contentInstructions = 'The paragraph must contain a mix of words and numbers (e.g., 123, 2024), along with basic punctuation.';
    } else if (includeSymbols) {
      contentInstructions = 'The paragraph must contain a mix of words and common keyboard symbols (e.g., !@#$%^&*), along with basic punctuation.';
    }
    
    const finalPrompt = `${promptBase} ${contentInstructions}`;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: finalPrompt,
      config: {
          thinkingConfig: { thinkingBudget: 0 } // For faster response
      }
    });

    const text = response.text;
    if (!text) {
        throw new Error("Received an empty response from the AI.");
    }
    
    // Clean up the response to remove potential markdown or extra quotes
    return text.trim().replace(/^"/, '').replace(/"$/, '');

  } catch (error) {
    console.error("Error generating practice text:", error);
    // Re-throw the error so the UI layer can handle it.
    // The Gemini SDK may provide informative error messages in the console.
    throw error;
  }
};
