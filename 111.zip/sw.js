const CACHE_NAME = 'typing-master-pro-v1';
const urlsToCache = [
  '/',
  'index.html',
  'favicon.svg',
  'manifest.json',
  'icons/icon-192.svg',
  'icons/icon-512.svg',
  'index.tsx',
  'App.tsx',
  'types.ts',
  'constants.ts',
  'components/Header.tsx',
  'components/TypingArea.tsx',
  'components/Keyboard.tsx',
  'components/Stats.tsx',
  'components/LessonSelector.tsx',
  'components/GenerateTextModal.tsx',
  'components/HandGuide.tsx',
  'components/ErrorBoundary.tsx',
  'components/AchievementToast.tsx',
  'components/Badge.tsx',
  'hooks/useTyping.ts',
  'data/lessons.ts',
  'data/badges.ts',
  'services/geminiService.ts',
];

self.addEventListener('install', event => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then(cache => {
        console.log('Opened cache and caching app shell');
        return cache.addAll(urlsToCache);
      })
  );
});

self.addEventListener('fetch', event => {
  event.respondWith(
    caches.match(event.request)
      .then(response => {
        // Cache hit - return response
        if (response) {
          return response;
        }

        // Not in cache - fetch from network, cache it, and then return it
        return fetch(event.request).then(
          response => {
            // Check if we received a valid response
            if (!response || response.status !== 200 || (response.type !== 'basic' && response.type !== 'cors')) {
              return response;
            }

            const responseToCache = response.clone();

            caches.open(CACHE_NAME)
              .then(cache => {
                cache.put(event.request, responseToCache);
              });

            return response;
          }
        );
      })
  );
});

self.addEventListener('activate', event => {
  const cacheWhitelist = [CACHE_NAME];
  event.waitUntil(
    caches.keys().then(cacheNames => {
      return Promise.all(
        cacheNames.map(cacheName => {
          if (cacheWhitelist.indexOf(cacheName) === -1) {
            console.log('Deleting old cache:', cacheName);
            return caches.delete(cacheName);
          }
        })
      );
    })
  );
});
