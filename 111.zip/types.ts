export interface Lesson {
  title: string;
  text: string;
  level: 'Beginner' | 'Intermediate' | 'Advanced' | 'Custom';
}

export interface TypingResult {
  wpm: number;
  accuracy: number;
  timestamp: number;
}

export type TypingStatus = 'idle' | 'typing' | 'finished' | 'paused';

export interface TypingState {
  status: TypingStatus;
  userInput: (string | undefined)[];
  currentIndex: number;
  startTime: number | null;
  wpm: number;
  accuracy: number;
  errorCount: number;
  pauseStartTime: number | null;
  totalPausedTime: number;
  elapsedTime: number;
}

export interface Badge {
  id: string;
  name: string;
  description: string;
  icon: string;
}